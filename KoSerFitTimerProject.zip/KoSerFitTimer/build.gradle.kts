
plugins {
    // empty on purpose (plugins are applied in subprojects)
}
